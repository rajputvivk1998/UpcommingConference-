<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Innovation and technology go hand in hand. When businesses and the way they operate shift from their traditional mode of operation and management ">
    <meta name="author" content="">

    <!-- Favicon -->
    <link rel="icon" type="image/png" href="images/favicon.png">
    <link rel="shortcut icon" type="image/png" href="images/favicon.png">

    <title>National Conference on “Recent Trends in Computer Science and Information Technology (NCRTCSIT-2019)”</title>

    <!-- Bootstrap Core CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">

    <!-- Custom CSS -->
    <link rel="stylesheet" type="text/css" href="css/style.css">

    <!-- Responsive stylesheet  -->
    <link rel="stylesheet" type="text/css" href="css/responsive.css">
  
</head>

<body id="page-top" data-spy="scroll" data-target=".navbar-fixed-top">

    <!-- Preloader -->
    <div id="preloader">
        <div id="status"></div>
    </div>
	
	

    <header class="main-header">	
		<section>
			<div class="container">
		  <div class="row " style="padding: 10px;">
			<div class="col-md-2">
			  <img src="images/logo/logo.png" class="img-fluid raisoni-logo">
			</div>
			<div class="col-md-8 ">         
			  <h3 class="font-weight-bold text-center">National Conference on <br>
				“Computational Intelligence and Deep Learning” 
				(NCCIDL)   
			  </h3>
			</div>
			<div class="col-md-2">
			  <img src="images/logo/RGI_LOGO.png" class="img-fluid raisoni-logo">
			</div>
		  </div>
		</div>
		</section>
        <!-- Navigation Start -->
        <div class="main-nav nav-transparent">
            <nav class="navbar navbar-default navbar-fixed-top" id="navbar-main">
                <div class="container">
                    <div class="navbar-header page-scroll">
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                        <!--<a class="navbar-brand page-scroll logo-black" href="#page-top"><img class="main-logo" src="images/logo/logo.png" alt=""> </a>
                        <a class="navbar-brand page-scroll logo-white" href="#page-top"><img class="main-logo" src="images/logo/logo.png" alt=""> </a>-->
                    </div>

                    <!-- Collect the nav links, forms, and other content for toggling -->
                    <div class="collapse navbar-collapse navbar-ex1-collapse">
                        <ul class="nav navbar-nav navbar-right">
                            <!-- Hidden li included to remove active class from about link when scrolled up past about section -->
                            <li> <a class="page-scroll" href="index.php">Home</a> </li>
                          
                            
							<li class="dropdown">
							  <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
							  About  <span class="caret"></span></a>
								<ul class="dropdown-menu submenu " role="menu">
									<li><a href="index.php#about">About Conference</a></li>									
									<li><a href="index.php#about">About GHRIIT</a></li>									
									<li><a href="index.php#about">About IJSRCSEIT Journal</a></li>									
									<li><a href="venu.php#aboutnagpur">About Nagpur</a></li>									
									<li><a href="KeynoteSpeaker.php">Keynote Speaker</a></li>									
								</ul>
							</li>							
							 
                            
							
							<li class="dropdown">
							  <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
							  Papers  <span class="caret"></span></a>
								<ul class="dropdown-menu submenu " role="menu">
									<li><a href="index.php#speakers">Call for Papers</a></li>									
									<li><a href="index.php#submission">Paper Submission</a></li>									
									<li><a href="index.php#PaperAccepted">Paper Accepted</a></li>									
								</ul>
							</li>
							
							<li class="dropdown">
							  <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
							  Registration  <span class="caret"></span></a>
								<ul class="dropdown-menu submenu " role="menu">
									<li><a href="index.php#Registration">Registration</a> </li>									
									<li><a href="index.php#ImportantDates">Important Dates</a> </li>									
									<li><a href="venu.php"> Venue</a></li>							
									<li><a href="index.php#download">Program and Schedule</a></li>							
								</ul>
							</li>
							
							
							
							
							
							
							
							<li class="dropdown">
							  <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
							Committee  <span class="caret"></span></a>
								<ul class="dropdown-menu submenu " role="menu">
									<li><a href="index.php#Conference">Conference Committee</a></li>
									<li><a href="index.php#Organizing">Organizing  Committee</a></li>
									<li><a href="#">Nagpur Travel and Tourism</a></li>
									<li><a href="#">Accommodation</a></li>
																	
								</ul>
							</li>
                            
                           
                           
							
							
                            <li> <a class="page-scroll" href="index.php#news">News</a></li>
                           
							<li class="dropdown">
							  <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
							Download  <span class="caret"></span></a>
								<ul class="dropdown-menu submenu " role="menu">
									<li><a href="#download">E-Brochure</a></li>
									
																	
								</ul>
							</li>
							
                           
							
							<li class="dropdown">
							  <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
							Contact  <span class="caret"></span></a>
								<ul class="dropdown-menu submenu " role="menu">
									<li><a href="#contact">Contact</a></li>
									<li><a href="contactperson.php">Contact Person</a></li>
									
																	
								</ul>
							</li>
							
							
							
							<!--<a class="navbar-brand" href="#page-top">
								<img class="main-logo" src="images/logo/RGI_LOGO.png" alt="">	
							</a>-->
                        </ul>
						
                    </div>
                    <!-- /.navbar-collapse -->
                </div>
                <!-- /.container -->
            </nav>
        </div>
    </header>

    <!-- Banner Start -->
    <section class="main-banner">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="header-banner">
						<h2>National Conference</h2>
						<h2>23<sup>rd</sup> March 2019</h2>
                        <h1>“Recent Trends in Computer Science <br>and Information Technology ”</h1>
                        <h3>Organized by</h3>
                        <h2>G. H. RAISONI INSTITUTE OF INFORMATION <br>TECHNOLOGY, NAGPUR</h2>
                        <div class='countdown' data-date="2018-12-30"></div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- About Start -->
    <section class="about-area" id="about">
        <img class="left-img" src="images/left-img.png" alt="">
        <img class="right-img" src="images/right-img.png" alt="">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div class="about-col text-justify">
                        <h3>About  <span>Conference</span></h3>
						<b>
						National Conference on Recent Trends in Computer Science and Information Technology (NCRTCSIT-2019) :
						</b>
                        <p>Computer Science and Information Technology play an important role in convergence of computing, communication 
						and all other computational sciences and applications to satisfy our ever-challenging needs. In the past few decades,
						Information Technology has influenced and changed every aspect of our lives along with cultures.  
						</p>
						<p>
						This technology will also transform the world in various areas which includes Science, Engineering, Industry, Business, 
						Law, Politics, Medicine, and other related. NCRTCSIT-2019 welcomes research papers from practicing Engineers and
						Technologists, Scientists from R & D Institutions, Faculty members of engineering colleges, Research 
						scholars and Post graduate students from Information Technology, Computer Science and Communication 
						fields all over the world. Our conference is intended to foster the dissemination of state-of-the-art
						research in all future IT areas, including IT models, services, and novel applications associated
						with the utilization of Information Science and Technology.
						</p><br>
						<b>Objective of the Conference :</b>
						<p>
						To provide a forum for professionals and academicians in the field of Computer Science & Information 
						Technology to share their views and ideas towards latest advancements in the field.
						</p><br>
						<b>Participants :</b>
						<p>
						The conference is especially designed for Computer Science and Information Technology faculty 
						Research scholars, People from industry and final year students who inherit interest towards research.
						</p>
						
						
                    </div>
                </div>
               
				<div class="col-md-6">
                    <div class="about-col">
                        <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
                            <div class="panel panel-default">
                                <div class="panel-heading" role="tab" id="headingOne">
                                    <h4 class="panel-title">
										<a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
										  About IJSRCSEIT Journal
										</a>
									</h4>
                                </div>
                                <div id="collapseOne" class="panel-collapse collapse " role="tabpanel" aria-labelledby="headingOne">
                                    <div class="panel-body">
                                        <p>
											<b>IJSRCSEIT Journals Details: </b><br>
											<span>ISSN: 2456-3307  </span><br>
											<span>UGC Approved Journal No: 64718</span><br>
											<span>Impact Factor = 4.032  </span>
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="panel panel-default">
                                <div class="panel-heading" role="tab" id="headingTwo">
                                    <h4 class="panel-title">
										<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
										 	About GHRIIT
										</a>
									</h4>
                                </div>
                                <div id="collapseTwo" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingTwo">
                                    <div class="panel-body">										
                                        <p>										
											<span>
												G. H. Raisoni Institute of Information Technology (G. H. R. I. I. T.) is a
												multidisciplinary amalgamation of fields with pure and applied composition.
												The institute boasts a bright success story which becomes evident from the 
												way it has expanded its scope.
											</span>
											<br>
											
											<span>
												The institute has benefited a large number of students with a technical 
												mindset who have the zeal to excel in the most competent and challenging 
												fields that promote the structure of the contemporary volatile market.
											</span>
											<br>
											
											<span>
												It was in 1999, when the institute started execution of the Masters 
												course in Computer Application. Till the date it has seen a structured 
												development in its ideology and implementations.
											</span>
											<br>
											
											<span>
												With the intent of imparting the rigorous training in the sector of the 
												interdisciplinary technology, providing an immense base for research and
												development activity and presenting the employers with the motivated, 
												knowledgeable and confident manpower, the institute stands tall among 
												the competitors with respect to both the respect and applicability.
											</span>
											<br>
											
											<span>
												The courses are approved and recognized by All India Council for Technical 
												Education (AICTE), New Delhi, Directorate of Technical Education (Government 
												of Maharashtra) and affiliated to Rashtrasant Tukadoji Maharaj Nagpur 
												University, Nagpur.
											</span>
											<br>
                                        </p>
                                    </div>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    	
	
    <!-- Call for Papers Start -->
    <section class="speakers-area parallax" id="speakers">
        <div class="container">
            <div class="row">
                <div class="col-md-8 col-md-offset-2">
                    <div class="section-title">
                        <h2>Call fo<span>r Papers</span></h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12 fw-600 text-justify">
					<p style="color: #fff;font-size: 18px;">
					NCRTCSIT-2019 is the premier forum for the presentation of Advancement in technology and research results.
					All the participants are encouraged for their contribution to the conference through submissions of 
					their research abstracts and papers. Originality and unpublished results of conceptual, experimental
					or theoretical work in all areas of computer science and information technology are encouraged and 
					cordially invited for presentation at the conference.
					</p><br>
					
					<h4 style="color: #f32d3a;">Computer Science Track</h4>
					<p style="color: #fff;font-size: 18px;">
					NCRTCSIT-2019 includes the research paper in the following areas (but not limited to this)
					</p><br>
				</div>				
				
					<div class="col-md-4 col-sm-12 col-xs-12 fw-600">
						<div class="speaker-col wow fadeInLeft animated" data-wow-duration=".5s" data-wow-delay="0s">
							<div class="speaker-box">								
							</div>
							<div class="speaker-info">
								<ul>
									<li>Artificial Intelligent System</li>
									<li>Software Engineering</li>
									<li>Big data Analysis</li>
									<li>Bio-Informatics</li>
									<li>Business Intelligence </li>
									<li>Cloud Computing </li>
									<li>Mobile Computing</li>
									<li>Algorithms and Applications</li>
									<li>Computer Networks</li>
									<li>Cryptography</li>
									<li>Data and Knowledge Processing</li>
								</ul>
							</div>
						</div>
					</div>
				
					<div class="col-md-4 col-sm-12 col-xs-12 fw-600">
						<div class="speaker-col wow fadeInLeft animated" data-wow-duration=".5s" data-wow-delay=".2s">
							<div class="speaker-box">
								
							</div>
							<div class="speaker-info">
								<ul>
									
									<li>Data mining Techniques</li>
									<li>Decision Support and Expert Systems </li>
									<li>Distributed Databases </li>
									<li>Fuzzy logic</li>
									<li>Genetic Algorithm </li>
									<li>Grid and parallel computing</li>
									<li>Image Processing, Knowledge Base System </li>
									<li>Mobile Networks</li>
									<li>Natural Language Processing </li>
									<li>Nano-computing </li>
									                              
								</ul>
							</div>
						</div>
					</div>
					
					
					<div class="col-md-4 col-sm-12 col-xs-12 fw-600">
						<div class="speaker-col wow fadeInLeft animated" data-wow-duration=".5s" data-wow-delay=".3s">
							<div class="speaker-box">
								
							</div>
							<div class="speaker-info">
								<ul>
									
									<li>Neural Networks </li>
									<li>Object-Oriented Modeling and Systems </li>
									<li>Ontologies and Semantics</li>
									<li>Parallel Processing </li>
									<li>Pattern Recognition</li>
									<li>Security and Privacy Issues</li>
									<li>Programming Methodologies</li>
									<li>Embedded System</li>
									<li>Real Time Operating System </li>
									<br>
									<br>
									                              
								</ul>
							</div>
						</div>
					</div>
            </div>
        </div>
    </section>

    <!-- Organizer Start -->
    <section class="organizer-area" id="submission">
        <img class="left-img" src="images/left-img.png" alt="">
        <img class="right-img" src="images/right-img.png" alt="">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div class="organizer-col text-justify">
                        <h3>Paper <span style="color: #f32d3a;">Submission</span> </h3>
                        
						<p>Computer Science Track</p>
                        <div class="speaker-info submission">
							<ul>
								<li>Authors can send their full length research paper in IJSRCSEIT format to the Mail Id  : 
								<b>NCRTCSIT2019@raisoni.net</b>
								</li>
								<li>All papers must be submitted in pdf and word format.</li>
								<li>To download the paper template <a>click here.</a></li>
								<li>The length of the research paper should not more than 6 pages. (For every additional page Rs. 50 will be charged).</li>
								<li>The paper must be accompanied with email ID and cell nos. of participants.</li>
								<li>After acceptance of paper, send registration form , concern of the all authors,
										copyright form, plagiarism report and final copy of the Research Paper in IJSRCSEIT format
										along with the receipt of payment (scan copy of Demand Draft/Cheque in case) to Mail Id  :
										<b>NCRTCSIT2019@raisoni.net</b>
								</li>
								<li>Author will receive Confirmation of paper within 7 days.</li>
								<li>All the selected papers will be published in the IJSRCSEIT Journal.</li>
								
							</ul>
						</div>
                        
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="organizer-col" style="margin-top: 5pc;">
                        <img src="images/bg/4.jpg" alt="">
                    </div>
                </div>
            </div>
        </div>
    </section>
	
	
	 <!-- Paper Accepted Start -->
    <section class="counter-area parallax" id="PaperAccepted">
        <div class="container">
            <div class="row">
				<div class="col-md-12">
                    <div class="ticket-col">
                        <h2>Paper   <span class="text1">Accepted</span> </h2>
                                               
                    </div>
                </div>
                
                <div class="col-md-12 col-sm-12 col-xs-12 fw-600">
                    <div class="counter-col">
                       
                        <p>List of Paper Accepted (will updated)</p>
                     
                    </div>
                </div>
               
                
            </div>
        </div>
    </section>

    

    <!-- Registration Fee Start -->
    <section class="schedule-area" id="Registration" >
        <img class="left-img" src="images/left-img.png" alt="">
        <img class="right-img" src="images/right-img.png" alt="">
        <div class="container">
            <div class="row">
                <div class="col-md-8 col-md-offset-2">
                    <div class="section-title">
                        <h2>Regis<span>tration  </span></h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
				    <div class="speaker-info submission">
					<h3>Registration and Payments</h3>
						<ul>
							<li>Authors can deposit the fees by post using Cheque / Demand Draft or by Cash / Online Banking to the given account.</li>
							<li>Cash payable at Institute.</li>	
						</ul>
					</div>
				</div>
				<div class="col-md-12">
				    <div class="speaker-info submission">
					<h3>Rules for Participation</h3>
						<ul>
							<li>Each participating author should register separately.</li>
							<li>Participation certificate will issued only to the registered participants.</li>	
						</ul>
					</div><br>
				</div>
                <div class="col-md-6">
				<h3>Registration fees</h3>
					<div class="table-responsive schedule-table">
						<table class="table table-bordered">
							<thead>
								<tr>
									<th>Sr. No.</th>
									<th>Author</th>
									<th>Total</th>                                
								</tr>
							</thead>
							<tbody>
								<tr>
									<td>01</td>
									<td>Student/Research Scholar</td>
									<td>1200 <i class="fa fa-inr"></i></td>                               
								</tr>
								<tr class="table-row-bg">
									<td>02</td>
									<td>Academicians</td>
									<td>1500 <i class="fa fa-inr"></i></td>                             
								</tr>
								<tr>
									<td>03</td>
									<td>Industry</td>
									<td>2000 <i class="fa fa-inr"></i></td>  
								</tr>
							</tbody>
						</table>
					</div>
                </div>
				
				<div class="col-md-6">
                    <div class="about-col">
                        <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
                            
                            <div class="panel panel-default">
                                <div class="panel-heading" role="tab" id="fee">
                                    <h4 class="panel-title">
									<a class="" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapsefee" aria-expanded="true" aria-controls="collapsefee">
									  The Registration fee includes: 
									</a>
									</h4>
                                </div>
                                <div id="collapsefee" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="fee" aria-expanded="true" style="">
                                    <div class="panel-body">
                                        
											<ul class="fess">
												<li>Online publication on journal site http://ijsrcseit.com</li>
												<li>Online publication on <a href="www.ghriit.raisoni.net">www.ghriit.raisoni.net</a></li>
												<li>Certification by college and journal</li>
												<li>Conference kit, lunch and tea on the day of conference </li>
											</ul>
										
                                    </div>
                                </div>
                            </div>
                             
                        </div>
                    </div>
                </div>
				
				<div class="col-md-12">
				    <div style="color: #f32d3a;">
						<p>* Additional Hard copy of the Journal can collect by paying Rs. 400/-</p>
						<p>* Registration fees will include conference kit, lunch and tea on the conference days.</p>
					</div><br>
				</div>
				<div class="row">
					<div class="col-md-12 ticket-col text-center" style="margin-bottom: 0px;">
						<h3>Account Details</h3>
					</div>
					
					<div class="col-md-8 col-md-offset-2">
						<div class="venue-col">
							<div class="info-box">
								
								<h4><i class="fa fa-bank"></i> Bank Name and Branch</h4>	
								<div class="table-responsive schedule-table">
									<table class="table table-hover" style="border: 2px solid #e7e7e796;">									
										<tbody>
											<tr>											
												<td>A/C NAME</td>
												<td>:</td>
												<td>“G.H. Raisoni Institute of Information Technology”, payable at Nagpur.</td>                               
											</tr>
											<tr class="table-row-bg">
												<td>BANK NAME</td>
												<td>:</td>
												<td>State Bank of India, MIDC, Nagpur-440016</td>                            
											</tr>
											<tr>
												<td>A/C Holder</td>
												<td>:</td>
												<td>-</td>
											</tr>
											<tr class="table-row-bg">
												<td>A/C NO</td>
												<td>:</td>
												<td>-</td> 
											</tr>
											<tr>
												<td>IFSC CODE</td>
												<td>:</td>
												<td>-</td>  
											</tr>
											
										</tbody>
									</table>
								</div>
							</div>                        
						</div>
					</div>
					
				</div>
            </div>
        </div>
    </section>
	<!-- Blog Start -->
    <section class="venue-area" id="ImportantDates">
        
        <div class="container">
            <div class="row">
                <div class="col-md-8 col-md-offset-2">
                    <div class="section-title">
                        <h2>Important  <span>Dates</span></h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-center">
                    <div class="col-md-4 col-sm-6 col-xs-6 fw-600">
                        <div class="blog-col date wow fadeInLeft animated" data-wow-duration=".5s" data-wow-delay="0s">
                            <div class="blog-img">                                
                                <div class="blog-date">
                                    <h3>11 March 2019</h3>
                                </div>
                            </div>
                            <div class="blog-content">
                                <h4><a>Submission Deadline </a></h4>                               
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-6 col-xs-6 fw-600">
                        <div class="blog-col date wow fadeInLeft animated" data-wow-duration=".5s" data-wow-delay=".2s">
                             <div class="blog-img">                                
                                <div class="blog-date">
                                    <h3>16 March 2019</h3>
                                </div>
                            </div>
                            <div class="blog-content">
                                <h4><a>Notification of Acceptance</a></h4>                               
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-6 col-xs-6 fw-600">
                        <div class="blog-col date wow fadeInLeft animated" data-wow-duration=".5s" data-wow-delay=".3s">
                             <div class="blog-img">                                
                                <div class="blog-date">
                                    <h3>19 March 2019</h3>
                                </div>
                            </div>
                            <div class="blog-content">
                                <h4><a>Registration Deadline</a></h4>                               
                            </div>
                        </div>
                    </div>
					<div class="col-md-4 col-sm-6 col-xs-6 fw-600">
                        <div class="blog-col date wow fadeInLeft animated" data-wow-duration=".5s" data-wow-delay=".3s">
                             <div class="blog-img">                                
                                <div class="blog-date">
                                    <h3>23 March 2019 </h3>
                                </div>
                            </div>
                            <div class="blog-content">
                                <h4><a>Conference Date</a></h4>                               
                            </div>
                        </div>
                    </div>
					
                </div>
            </div>
        </div>
    </section>
	
    <!-- Mode of Payment Start -->
    <section class="venue-area" id="venue" >
        <div class="container">
            <div class="row">
                <div class="col-md-8 col-md-offset-2">
                    <div class="section-title">
                        <h2><span>Mode of </span> Payment</h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12 ticket-col text-center">
					<h3>Payment shall be made by online bank transfer </h3>
				</div>
				
                <div class="col-md-6 col-md-offset-3">
                    <div class="venue-col">
                        <div class="info-box">
                            <i class="fa fa-bank"></i>
                            <h4>Bank Name and Branch</h4>	
							<div class="table-responsive schedule-table">
								<table class="table table-hover">									
									<tbody>
										<tr>											
											<td>A/C NAME</td>
											<td>:</td>
											<td>G H R LABS & RESEARCH CENTRE</td>                               
										</tr>
										<tr class="table-row-bg">
											<td>BANK NAME</td>
											<td>:</td>
											<td>IDBI BANK, NAGPUR</td>                            
										</tr>
										<tr>
											<td>A/C NAME</td>
											<td>:</td>
											<td>G H R LABS & RESEARCH CENTRE</td>
										</tr>
										<tr class="table-row-bg">
											<td>A/C NO</td>
											<td>:</td>
											<td>510102000006583</td> 
										</tr>
										<tr>
											<td>IFSC CODE</td>
											<td>:</td>
											<td>IBKL0000510</td>  
										</tr>
										
									</tbody>
								</table>
							</div>
                        </div>                        
                    </div>
                </div>
                
            </div>
        </div>
    </section>
	
	<!-- Paper Submission Start -->
    <section class="ticket-area parallax" id="guidelines" >
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <div class="ticket-col">
                        <h2>Guidelines for </h2>
                        <h3>Paper Submission</h3>                        
                    </div>
                </div>
                <div class="col-md-8">
                    <div class="ticket-col">
                        <div class="table-responsive schedule-table">
            			<table class="table  tbl-custom">
            			
            				<tbody>
            					<tr>
            						<td><b>Page size </b></td>
									<td>:</td>
            						<td> A4 size only</td>
            					</tr>
            					<tr>
            						<td><b>Alignment</b></td>
									<td>:</td>
            						<td>justify</td>
            					</tr>
            					<tr>
            						<td><b>Title</b></td>
									<td>:</td>
            						<td>24pt Times New Roman align: centre</td>
            					</tr>
            					<tr>
            						<td><b>Page Margins</b></td>
									<td>:</td>
            						<td> 1” All Sides</td>
            					</tr>
            					<tr>
            						<td><b>Font</b></td>
									<td>:</td>
            						<td>Use only 12pt Times New Roman for whole paper</td>
            					</tr>
								<tr>
            						<td><b>Figure caption</b></td>
									<td>:</td>
            						<td>Font size- 10, lower case and Write below the figure, position-center</td>
            					</tr>
								<tr>
            						<td><b>Table Caption</b></td>
									<td>:</td>
            						<td>Font- 10”, lower case and Top of the table, position-center</td>
            					</tr>
								<tr>
            						<td><b>Paragraph</b></td>
									<td>:</td>
            						<td>Paragraph Indentation by- 0.2”</td>
            					</tr>
								<tr>
            						<td><b>Line Spacing</b></td>
									<td>:</td>
            						<td>1.5, Header 0.5” footer 0.3”</td>
            					</tr>
            					
            				</tbody>
            			</table>
            		</div>
                    </div>
                </div>
            </div>
        </div>
    </section>

     <!-- Conference Committee Start -->
    <section class="counter-area parallax" id="Conference" >
        <div class="container">
            <div class="row">
				<div class="col-md-12">
                    <div class="ticket-col">
                        <h2>Conference   <span class="text1">Committee</span> </h2>                                               
                    </div>
					
					<h3 style="color:#fff;">Patron </h3>
               
					<div class="col-md-4 col-sm-6 col-xs-6 fw-600">
						<div class="counter-col">
							<div class="counter">                            
								<img src="images/icon/1.png" alt="">
							</div>
							<p>Shri. Sunil Raisoni</p>
							<p>Chairman (RGI)</p>
							
						</div>
					</div>
					<div class="col-md-4 col-sm-6 col-xs-6 fw-600">
						<div class="counter-col">
							<div class="counter">                            
								<img src="images/icon/2.png" alt="">
							</div>
							<p>Dr. Onkar Bihade</p>
							<p>Executive Director (RGI)</p>                        
						</div>
					</div> 
					
					<div class="col-md-4 col-sm-6 col-xs-6 fw-600">
						<div class="counter-col">
							<div class="counter">                            
								<img src="images/icon/2.png" alt="">
							</div>
							<p>Dr. Vivek Kapur</p>
							<p>Director (RGI)</p>                        
						</div>
					</div> 
				
                </div>
				
				 
				<div class="col-md-4">
                    <div class="">                      
						<h3 style="color:#fff;">Chairman </h3>						
                    </div>               
					<div class="col-md-12 col-sm-6 col-xs-6 fw-600">
						<div class="counter-col">
							<div class="counter">                            
								<img src="images/icon/4.png" alt="">
							</div>
							<p>Dr. Mamta Muthal </p>
							<p>Principal, GHRIIT</p>							
						</div>
					</div>                               
                </div>
				<div class="col-md-4">
                    <div class="">                      
						<h3 style="color:#fff;">Convener </h3>						
                    </div>               
					<div class="col-md-12 col-sm-6 col-xs-6 fw-600">
						<div class="counter-col">
							<div class="counter">                            
								<img src="images/icon/4.png" alt="">
							</div>
							<p>Mr. Dhiraj Rane</p>
							<br>						
						</div>
					</div>                               
                </div>
				<div class="col-md-4">
                    <div class="">                      
						<h3 style="color:#fff;">Organizing Secretory  </h3>						
                    </div>               
					<div class="col-md-12 col-sm-6 col-xs-6 fw-600">
						<div class="counter-col">
							<div class="counter">                            
								<img src="images/icon/4.png" alt="">
							</div>
							<p>Mrs. Rashmi Dukhi</p>
							<br>							
						</div>
					</div>                               
                </div>
            </div>
        </div>
    </section>

   

    <!-- Organizing Start -->
    <section class="sponsor-area" id="Organizing">
        <img class="left-img" src="images/left-img.png" alt="">
        <img class="right-img" src="images/right-img.png" alt="">
        <div class="container">
            <div class="row">
                <div class="col-md-8 col-md-offset-2">
                    <div class="section-title">
                        <h2>Organizing <span>Committee</span></h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-center">
                    <div class="col-md-4 col-sm-6 col-xs-6 fw-600">
                        <div class="blog-col wow fadeInLeft animated" data-wow-duration=".5s" data-wow-delay="0s">                            
                            <div class="blog-content">
                                <h4><a>Mr. Sudhir Juare</a></h4>                               
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-6 col-xs-6 fw-600">
                        <div class="blog-col wow fadeInLeft animated" data-wow-duration=".5s" data-wow-delay=".2s">                             
                            <div class="blog-content">
                                <h4><a>Mr. Rupali Chikhale</a></h4>                               
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-6 col-xs-6 fw-600">
                        <div class="blog-col wow fadeInLeft animated" data-wow-duration=".5s" data-wow-delay=".3s">                           
                            <div class="blog-content">
                                <h4><a>Mr. Anupam Choubey</a></h4>                               
                            </div>
                        </div>
                    </div>
					<div class="col-md-4 col-sm-6 col-xs-6 fw-600">
                        <div class="blog-col wow fadeInLeft animated" data-wow-duration=".5s" data-wow-delay=".3s">                             
                            <div class="blog-content">
                                <h4><a>Mrs. Shubhangi Daware</a></h4>                               
                            </div>
                        </div>
                    </div>
					<div class="col-md-4 col-sm-6 col-xs-6 fw-600">
                        <div class="blog-col wow fadeInLeft animated" data-wow-duration=".5s" data-wow-delay=".3s">                            
                            <div class="blog-content">
                                <h4><a>Ms. Sandhya Dahake</a></h4>                               
                            </div>
                        </div>
                    </div>
					
                </div>
            </div>
			<hr>
			
			<div class="row">
                <div class="col-md-12">
                    <div class="">
                        <h3>Keynote  <span class="text1">Speaker</span></h3>
                    </div><br>
                </div>
				
				<div class="col-md-4 col-sm-6 col-xs-6 fw-600">
					<div class="blog-col wow fadeInLeft animated" data-wow-duration=".5s" data-wow-delay="0s">                            
						<div class="blog-content">
							<h4><a>Dr. K. V. Kale</a></h4>                               
						</div>
					</div>
				</div>
				<div class="col-md-4 col-sm-6 col-xs-6 fw-600">
					<div class="blog-col wow fadeInLeft animated" data-wow-duration=".5s" data-wow-delay=".2s">                             
						<div class="blog-content">
							<h4><a>Dr. V. M. Thakare</a></h4>                               
						</div>
					</div>
				</div>
            </div>
			<hr>
			
			
			<div class="row">
                <div class="col-md-12">
                    <div class="">
                        <h3>Research Advisory    <span class="text1">Committee</span></h3>
                    </div>
					<p style="color: #f32d3a;font-weight: 600;">NCRTCSIT: Computer Science </p>
					<br>
                </div>
				
				<div class="col-center">
                    <div class="col-md-4 col-sm-6 col-xs-6 fw-600">
                        <div class="blog-col wow fadeInLeft animated" data-wow-duration=".5s" data-wow-delay="0s">                            
                            <div class="blog-content">
                                <h4><a>Dr. Pradip Butey</a></h4>                               
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-6 col-xs-6 fw-600">
                        <div class="blog-col wow fadeInLeft animated" data-wow-duration=".5s" data-wow-delay=".2s">                             
                            <div class="blog-content">
                                <h4><a>Dr. Satish Sharma</a></h4>                               
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-6 col-xs-6 fw-600">
                        <div class="blog-col wow fadeInLeft animated" data-wow-duration=".5s" data-wow-delay=".3s">                           
                            <div class="blog-content">
                                <h4><a>Dr. Subhash Pande</a></h4>                               
                            </div>
                        </div>
                    </div>
					<div class="col-md-4 col-sm-6 col-xs-6 fw-600">
                        <div class="blog-col wow fadeInLeft animated" data-wow-duration=".5s" data-wow-delay=".3s">                             
                            <div class="blog-content">
                                <h4><a>Dr. Mahendra Dhore</a></h4>                               
                            </div>
                        </div>
                    </div>
					<div class="col-md-4 col-sm-6 col-xs-6 fw-600">
                        <div class="blog-col wow fadeInLeft animated" data-wow-duration=".5s" data-wow-delay=".3s">                            
                            <div class="blog-content">
                                <h4><a>Dr. Vinay Chavan</a></h4>                               
                            </div>
                        </div>
                    </div>
					
					
					<!-------------------------->
					<div class="col-md-4 col-sm-6 col-xs-6 fw-600">
                        <div class="blog-col wow fadeInLeft animated" data-wow-duration=".5s" data-wow-delay=".4s">                             
                            <div class="blog-content">
                                <h4><a>Dr. S. B. Kishore</a></h4>                               
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-6 col-xs-6 fw-600">
                        <div class="blog-col wow fadeInLeft animated" data-wow-duration=".5s" data-wow-delay=".5s">                           
                            <div class="blog-content">
                                <h4><a>Dr. Ashish Sasankar</a></h4>                               
                            </div>
                        </div>
                    </div>
					<div class="col-md-4 col-sm-6 col-xs-6 fw-600">
                        <div class="blog-col wow fadeInLeft animated" data-wow-duration=".5s" data-wow-delay=".6s">                             
                            <div class="blog-content">
                                <h4><a>Dr. Girish Katkar</a></h4>                               
                            </div>
                        </div>
                    </div>
					<div class="col-md-4 col-sm-6 col-xs-6 fw-600">
                        <div class="blog-col wow fadeInLeft animated" data-wow-duration=".5s" data-wow-delay=".7s">                            
                            <div class="blog-content">
                                <h4><a>Dr. Ravi Jugele</a></h4>                               
                            </div>
                        </div>
                    </div>
					
                </div>
            </div>
			<hr>
			
			<div class="row">
                <div class="col-md-12">
                    <div class="">
                        <h3>Editing and Core <span class="text1">Committee Member</span></h3>
                    </div><br>
                </div>
				<div class="col-center">
					<div class="col-md-3 col-sm-6 col-xs-6 fw-600">
						<div class="blog-col wow fadeInLeft animated" data-wow-duration=".5s" data-wow-delay=".8s">  					
							<div class="blog-content">
								<h4><a>Dr. Neeraj Shahu</a></h4>                               
							</div>
						</div>
					</div>
					<div class="col-md-3 col-sm-6 col-xs-6 fw-600">
						<div class="blog-col wow fadeInLeft animated" data-wow-duration=".5s" data-wow-delay=".9s">                             
							<div class="blog-content">
								<h4><a>Mr. Sudhir Juare</a></h4>                               
							</div>
						</div>
					</div>
					<div class="col-md-3 col-sm-6 col-xs-6 fw-600">
						<div class="blog-col wow fadeInLeft animated" data-wow-duration=".5s" data-wow-delay=".10s">  					
							<div class="blog-content">
								<h4><a>Mr. Dhiraj Rane</a></h4>                               
							</div>
						</div>
					</div>
					<div class="col-md-3 col-sm-6 col-xs-6 fw-600">
						<div class="blog-col wow fadeInLeft animated" data-wow-duration=".5s" data-wow-delay=".11s">                             
							<div class="blog-content">
								<h4><a>Mr. Anupam Choubay</a></h4>                               
							</div>
						</div>
					</div>
				</div>
				
            </div>
			<hr>
			
			<div class="row">
                <div class="col-md-6">
				<h3> <span class="text1">Publication Committee</span></h3>
                    <div class="speaker-info submission">
					 
						<ul>
							<li>Dr. Dhiraj Shembekar </li>
							<li>Ms. Bhagyashree Ambulkar</li>	
						</ul>
					</div>
                </div>
				<div class="col-md-6">
					<h3><span class="text1">Finance</span></h3>
				    <div class="speaker-info submission">
					 
						<ul>
							<li>Mrs. Rupali Ghule (Chikhale)</li>
						
						</ul>
					</div>
				</div>
				
            </div>
			<hr>
			
			<div class="row">
                <div class="col-md-8">
				<h3><span class="text1">Technical</span> and Event Organizing Committee</h3>
                    <div class="speaker-info submission">
					 
						<ul>
							<li>Dr. Dhiraj Shembekar</li>
							<li>Dr. Neeraj Shahu</li>	
							<li>Ms. Manisha Gedam</li>	
							<li>Mrs. Deepali Bhende</li>	
							<li>Mr. Ashish Musale</li>	
						</ul>
					</div>
                </div>
				<div class="col-md-4">
					<h3>  <span class="text1">Hospitality Committee</span></h3>
				    <div class="speaker-info submission">
					 
						<ul>
							<li>Ms. Bhagyashree Ambulkar</li>
							<li>Mrs. Usha Kosarkar</li>
							<li>Mrs. Preeti Agrawal</li>
							<li>Mr. Ashish Musale</li>
						
						</ul>
					</div>
				</div>
				
            </div>
			
			
        </div>
    </section>

    
	<!-- Conference News Start -->
    <section class="speakers-area parallax" id="news">
        <div class="container">
            <div class="row">
                <div class="col-md-8 col-md-offset-2">
                    <div class="section-title">
                        <h2>Conference <span>News</span></h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12 fw-600 text-justify">
					<p style="color: #fff;font-size: 18px;">
					NCRTCSIT-2019 is the premier forum for the presentation of Advancement in technology and research results.
					All the participants are encouraged for their contribution to the conference through submissions of 
					their research abstracts and papers. Originality and unpublished results of conceptual, experimental 
					or theoretical work in all areas of computer science and information technology are encouraged and
					cordially invited for presentation at the conference.
					</p><br>
				</div>
            </div>
        </div>
    </section>
	
	 <!-- download Start -->
    <section class="sponsor-area" id="download">
        <img class="left-img" src="images/left-img.png" alt="">
        <img class="right-img" src="images/right-img.png" alt="">
        <div class="container">
            <div class="row">
                <div class="col-md-8 col-md-offset-2">
                    <div class="section-title">
                        <h2>downl<span>oad</span></h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-center">
                    <div class="col-md-3 col-sm-6 col-xs-6 fw-600">
                        <div class="blog-col wow fadeInLeft animated" data-wow-duration=".5s" data-wow-delay="0s">                            
                            <div class="blog-content">
                                <h4><a href="#" download ><i class="fa fa-download"></i> Registration Form</a></h4>                               
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 col-xs-6 fw-600">
                        <div class="blog-col wow fadeInLeft animated" data-wow-duration=".5s" data-wow-delay=".2s">                             
                            <div class="blog-content">
                                <h4><a href="#" download ><i class="fa fa-download"></i> Authors Undertaking</a></h4>                               
                            </div>
                        </div>
                    </div>
					<div class="col-md-3 col-sm-6 col-xs-6 fw-600">
                        <div class="blog-col wow fadeInLeft animated" data-wow-duration=".5s" data-wow-delay=".2s">                             
                            <div class="blog-content">
                                <h4><a href="#" download ><i class="fa fa-download"></i> E-Brochure</a></h4>                               
                            </div>
                        </div>
                    </div>
					<div class="col-md-3 col-sm-6 col-xs-6 fw-600">
                        <div class="blog-col wow fadeInLeft animated" data-wow-duration=".5s" data-wow-delay=".2s">                             
                            <div class="blog-content">
                                <h4><a href="#" download ><i class="fa fa-download"></i><!--Program and --> Schedule</a></h4>                               
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
	<!-- Google map -->
    <div id="" class="theme-color" style="height: 400px; width: 100%;">
		<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d59550.19160122287!2d79.00033289245818!3d21.11707179107959!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bd4eab12bd10cef%3A0xbf126089c3d6267a!2sG+H+Raisoni+Polytechnic+Nagpur!5e0!3m2!1sen!2sin!4v1546605520631" width="100%" height="400" frameborder="0" style="border:0" allowfullscreen></iframe>
	</div>

    <!-- Contact Start -->
    <section class="contact-area" id="contact">
        <img class="left-img" src="images/left-img.png" alt="">
        <img class="right-img" src="images/right-img.png" alt="">
        <div class="container">
			<div class="row">
                <div class="col-md-8 col-md-offset-2">
                    <div class="section-title">
                        <h2>Contact  <span>Details</span></h2>
                    </div>
                </div>
            </div>
            <div class="row">
				
			
             


				
                <div class="">				
                    <div class="col-md-4 col-sm-6">
                        <div class="contact-col contact-infobox">
                            <i class="fa fa-envelope-o" aria-hidden="true"></i>
                            <p>College Website: <a href="http://ghriit.raisoni.net/" target="_blank">http://ghriit.raisoni.net/ </a></p>
                           <br>
                           <br>
                          
                          
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-6">
                        <div class="contact-col contact-infobox">
                            <i class="fa fa-phone" aria-hidden="true"></i>
                            <p>Phone: +91 – 7104 – 236102  </p>
                            <p>Fax: +91 – 7104 - 236100 </p><br>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-6">
                        <div class="contact-col contact-infobox">
                            <i class="fa fa-map-marker" aria-hidden="true"></i>                            
                            <p>B-3739/1, Shradha Park, </p>
                            <p>MIDC Hingna-Wadi Link Road,</p>
                            <p> Nagpur – 440028, (INDIA)</p>
                        </div>
                    </div>
					
					<div class="col-md-4 col-sm-6">
                        <div class="contact-col contact-infobox">
                            <i class="fa fa-envelope-o" aria-hidden="true"></i>
							
                            <p>NCRTCSIT: Computer Science : <a href="#" target="_blank">http://ghriit.raisoni.net/NCRTCSIT2019 </a></p>
                            <p>Email: NCRTCSIT2019@raisoni.net</p>
                           
                          
                          
                        </div>
                    </div>
					
					<div class="col-md-4 col-sm-6">
                        <div class="contact-col contact-infobox">
                            <i class="fa fa-envelope-o" aria-hidden="true"></i>
                            <p>Synergy: Management: <a href="#" target="_blank">http://ghriit.raisoni.net/SYNERGY2019</a></p>
                           
                            <p>SYNERGY2019@raisoni.net</p>
                          
                          
                        </div>
                    </div>
                </div>
            </div>
            <div class="row contact-form-row" style="display:none;">
                <div class="col-md-8 col-md-offset-2">
                    <div class="row">
                        <div class="contact-col">
                            <form id="ajax-contact" method="post" action="http://mvcsoftonline.com/html/ict/php/contact.php">
                                <div class="col-md-6">
                                    <input type="text" name="name" id="name" class="form-control" placeholder="Your Name" required>
                                </div>
                                <div class="col-md-6">
                                    <input type="email" name="email" id="email" class="form-control" placeholder="Your Email"  required>
                                </div>
                                <div class="col-md-12">
                                    <input type="text" name="subject" class="form-control" placeholder="Subject" id="subject" required>
                                </div>
                                <div class="col-md-12">
                                    <div class="contact-textarea">
                                        <textarea class="form-control" rows="6" placeholder="Wright Message" id="message" name="message" required></textarea>
                                        <button class="btn btn-default my-btn btn-color text-center" type="submit" value="Submit Form">Send Message</button>
                                    </div>
                                </div>
                                <div id="form-messages"></div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

<!-- Footer Start -->
    <footer class="footer-area">
        <div class="container">
            <div class="row">                
                <div class="col-md-12">
                    <div class="footer-col hi-icon-wrap hi-icon-effect-4 hi-icon-effect-4b">
                        <a href="https://www.facebook.com/raisoniworld" target="_blank" title="facebook" class="hi-icon">
                             <i class="fa fa-facebook" aria-hidden="true"></i>
                        </a>
                        <a href="https://twitter.com/raisoniworld" target="_blank" title="twitter" class="hi-icon">
                             <i class="fa fa-twitter" aria-hidden="true"></i>
                        </a>
                        <a href="https://www.youtube.com/user/rgingp/videos" target="_blank" title="youtube" class="hi-icon">
                             <i class="fa fa-youtube" aria-hidden="true"></i>
                        </a>
                        <a href="https://www.linkedin.com/in/raisonigroupofinstitutions/" target="_blank" title="linkedin" class="hi-icon">
                            <i class="fa fa-linkedin" aria-hidden="true"></i>
                        </a>
                        <a href="https://www.pinterest.com/raisoninagpur/" target="_blank" title="pinterest" class="hi-icon">
                             <i class="fa fa-pinterest-p" aria-hidden="true"></i>
                        </a>
                    </div> 
                </div>
            </div>
        </div>
    </footer>

    <section class="footer-copy-right text-white">
        <div class="container">
            <div class="row">
                <div class="col-md-12 text-center">
                    <div class="">
					
						<p><small>© 2019 Designed by <br> 

							<a href="https://globaledu.net.in/" target="_blank"> <small>Global Education Limited.</small></a>

						</small> <br>

							All Rights Reserved by G H Raisoni Institute Of Information Technology, Nagpur</p>
					</div>
                </div>
            </div>
        </div>
    </section>
    <!-- Footer Style Background ten End -->


    <!-- jQuery -->
    <script src="js/jquery.min.js"></script>

    <!-- Bootstrap Min js -->
    <script src="js/bootstrap.min.js"></script>
    <!-- jquery easing JS -->
    <script src="js/jquery.easing.min.js"></script>
    <!-- scrolling-nav JS -->
    <script src="js/scrolling-nav.js"></script>
    <!-- counterup -->
    <script src="js/jquery.counterup.min.js"></script>
    <!-- waypoints -->
    <script src="js/jquery.waypoints.min.js"></script>
    <!-- carousel -->
    <script src="js/owl.carousel.min.js"></script>
    <!-- wow js -->
    <script src="js/wow.min.js"></script>
    <!-- countdown JS -->
    <script src="js/countdown.js"></script>
    <!-- jquery.plate JS -->
    <script src="js/jquery.plate.js"></script>
    <!-- jarallax JS -->
    <script src="js/jarallax.min.js"></script>
    <!-- jquery scrollUp  JS -->
    <script src="js/jquery.scrollUp.min.js"></script>


    <!-- Map API Key -->
    <script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBWJqEQulUkszx4CH5sRCtFBXyMo8KWyd4&amp;callback=initMap"
            type="text/javascript"></script>
    <script src="js/map.js"></script>

    <!-- Main Custom JS -->
    <script src="js/custom.js"></script>
	

</body>
</html>