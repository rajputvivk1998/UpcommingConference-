<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Innovation and technology go hand in hand. When businesses and the way they operate shift from their traditional mode of operation and management ">
    <meta name="author" content="">

    <!-- Favicon -->
    <link rel="icon" type="image/png" href="images/favicon.png">
    <link rel="shortcut icon" type="image/png" href="images/favicon.png">

    <title>National Conference on “Recent Trends in Computer Science and Information Technology (NCRTCSIT-2019)”</title>

    <!-- Bootstrap Core CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">

    <!-- Custom CSS -->
    <link rel="stylesheet" type="text/css" href="css/style.css">

    <!-- Responsive stylesheet  -->
    <link rel="stylesheet" type="text/css" href="css/responsive.css">
  
</head>

<body id="page-top" data-spy="scroll" data-target=".navbar-fixed-top">

    <!-- Preloader -->
    <div id="preloader">
        <div id="status"></div>
    </div>
	
	

    <header class="main-header">	
		<section>
			<div class="container">
		  <div class="row " style="padding: 10px;">
			<div class="col-md-2">
			  <img src="images/logo/logo.png" class="img-fluid raisoni-logo">
			</div>
			<div class="col-md-8 ">         
			  <h3 class="font-weight-bold text-center">National Conference on <br>
				“Computational Intelligence and Deep Learning” 
				(NCCIDL)   
			  </h3>
			</div>
			<div class="col-md-2">
			  <img src="images/logo/RGI_LOGO.png" class="img-fluid raisoni-logo">
			</div>
		  </div>
		</div>
		</section>
        <!-- Navigation Start -->
        <div class="main-nav nav-transparent">
            <nav class="navbar navbar-default navbar-fixed-top" id="navbar-main">
                <div class="container">
                    <div class="navbar-header page-scroll">
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                        <!--<a class="navbar-brand page-scroll logo-black" href="#page-top"><img class="main-logo" src="images/logo/logo.png" alt=""> </a>
                        <a class="navbar-brand page-scroll logo-white" href="#page-top"><img class="main-logo" src="images/logo/logo.png" alt=""> </a>-->
                    </div>

                    <!-- Collect the nav links, forms, and other content for toggling -->
                    <div class="collapse navbar-collapse navbar-ex1-collapse">
                        <ul class="nav navbar-nav navbar-right">
                            <!-- Hidden li included to remove active class from about link when scrolled up past about section -->
                            <li> <a class="page-scroll" href="index.php">Home</a> </li>
                          
                            
							<li class="dropdown">
							  <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
							  About  <span class="caret"></span></a>
								<ul class="dropdown-menu submenu " role="menu">
									<li><a href="index.php#about">About Conference</a></li>									
									<li><a href="index.php#about">About GHRIIT</a></li>									
									<li><a href="index.php#about">About IJSRCSEIT Journal</a></li>									
									<li><a href="venu.php#aboutnagpur">About Nagpur</a></li>									
									<li><a href="KeynoteSpeaker.php">Keynote Speaker</a></li>									
								</ul>
							</li>							
							 
                            
							
							<li class="dropdown">
							  <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
							  Papers  <span class="caret"></span></a>
								<ul class="dropdown-menu submenu " role="menu">
									<li><a href="index.php#speakers">Call for Papers</a></li>									
									<li><a href="index.php#submission">Paper Submission</a></li>									
									<li><a href="index.php#PaperAccepted">Paper Accepted</a></li>									
								</ul>
							</li>
							
							<li class="dropdown">
							  <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
							  Registration  <span class="caret"></span></a>
								<ul class="dropdown-menu submenu " role="menu">
									<li><a href="index.php#Registration">Registration</a> </li>									
									<li><a href="index.php#ImportantDates">Important Dates</a> </li>									
									<li><a href="venu.php"> Venue</a></li>							
									<li><a href="index.php#download">Program and Schedule</a></li>							
								</ul>
							</li>
							
							
							
							
							
							
							
							<li class="dropdown">
							  <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
							Committee  <span class="caret"></span></a>
								<ul class="dropdown-menu submenu " role="menu">
									<li><a href="index.php#Conference">Conference Committee</a></li>
									<li><a href="index.php#Organizing">Organizing  Committee</a></li>
									<li><a href="#">Nagpur Travel and Tourism</a></li>
									<li><a href="#">Accommodation</a></li>
																	
								</ul>
							</li>
                            
                           
                           
							
							
                            <li> <a class="page-scroll" href="index.php#news">News</a></li>
                           
							<li class="dropdown">
							  <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
							Download  <span class="caret"></span></a>
								<ul class="dropdown-menu submenu " role="menu">
									<li><a href="#download">E-Brochure</a></li>
									
																	
								</ul>
							</li>
							
                           
							
							<li class="dropdown">
							  <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
							Contact  <span class="caret"></span></a>
								<ul class="dropdown-menu submenu " role="menu">
									<li><a href="#contact">Contact</a></li>
									<li><a href="contactperson.php">Contact Person</a></li>
									
																	
								</ul>
							</li>
							
							
							
							<!--<a class="navbar-brand" href="#page-top">
								<img class="main-logo" src="images/logo/RGI_LOGO.png" alt="">	
							</a>-->
                        </ul>
						
                    </div>
                    <!-- /.navbar-collapse -->
                </div>
                <!-- /.container -->
            </nav>
        </div>
    </header><!-- Paper Submission Start -->
    <section class="ticket-area parallax" id="guidelines" >       
    </section>

 <!-- download Start -->
    <section class="sponsor-area" id="">
        <img class="left-img" src="images/left-img.png" alt="">
        <img class="right-img" src="images/right-img.png" alt="">
        <div class="container">
            <div class="row">
                <div class="col-md-8 col-md-offset-2">
                    <div class="section-title">
                        <h2>Contact <span>Person</span></h2>
                    </div>
                </div>
            </div>
            <div class="row">
				<div class="col-md-12 text-center">
					<h3>About Conference :</h3>
				</div>
                <div class="col-center">
                    <div class="col-md-6 col-sm-6 col-xs-6 fw-600">
                        <div class="blog-col wow fadeInLeft animated" data-wow-duration=".5s" data-wow-delay="0s">                            
                            <div class="blog-content">
                                <h4>Dr. Mamta Muthal</h4>                             
                                <p><b>Mail ID:</b> mamta.muthal@raisoni.net</p>
								<p><b>Mob:</b> 9881237717</p> 
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-sm-6 col-xs-6 fw-600">
                        <div class="blog-col wow fadeInLeft animated" data-wow-duration=".5s" data-wow-delay=".2s">                             
                            <div class="blog-content">
                                <h4>Mr. Sudhir Juare</h4>                             
                                <p><b>Mail ID:</b> sudhir.juare@raisoni.net</p>
								<p><b>Mob:</b> 9371996853</p> 
                            </div>
                        </div>
                    </div>
					
                </div>
            </div>
			
			<hr>
			
			<div class="row">
				<div class="col-md-12 text-center">
					<h3>About Papers Submission and Registration:</h3>
					<h4>NCRTCSIT: Computer Science </h4>
				</div>
                <div class="col-center">
                    <div class="col-md-6 col-sm-6 col-xs-6 fw-600">
                        <div class="blog-col wow fadeInLeft animated" data-wow-duration=".5s" data-wow-delay="0s">                            
                            <div class="blog-content">
                                <h4>Mr. Dhiraj Rane</h4>                             
                                <p><b>Mail ID:</b> dhiraj.rane@raisoni.net</p>
								<p><b>Mob:</b> 9881711774</p> 
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-sm-6 col-xs-6 fw-600">
                        <div class="blog-col wow fadeInLeft animated" data-wow-duration=".5s" data-wow-delay=".2s">                             
                            <div class="blog-content">
                                <h4>Mrs. Rashmi Dukhi</h4>                             
                                <p><b>Mail ID:</b> rashmi.dukhi@raisoni.net</p>
								<p><b>Mob:</b> 7507760110</p> 
                            </div>
                        </div>
                    </div>
					
                </div>
            </div>
			
			<hr>
			
			<div class="row">
				<div class="col-md-12 text-center">
					<h3>About Accomodation :</h3>
					
				</div>
                <div class="col-center">
                    <div class="col-md-6 col-sm-6 col-xs-6 fw-600">
                        <div class="blog-col wow fadeInLeft animated" data-wow-duration=".5s" data-wow-delay="0s">                            
                            <div class="blog-content">
                                <h4>Ms. Bhagyashree Ambulkar</h4>                             
                                <p><b>Mail ID:</b> bhagyshree.ambulkar@raisoni.net</p>
								<p><b>Mob:</b> 9763316989</p> 
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-sm-6 col-xs-6 fw-600">
                        <div class="blog-col wow fadeInLeft animated" data-wow-duration=".5s" data-wow-delay=".2s">                             
                            <div class="blog-content">
                                <h4>Mrs. Rashmi Dukhi</h4>                             
                                <p><b>Mail ID:</b> rashmi.dukhi@raisoni.net</p>
								<p><b>Mob:</b> 9422154851</p> 
                            </div>
                        </div>
                    </div>
					
                </div>
            </div>
			
        </div>
    </section>
<!-- Footer Start -->
    <footer class="footer-area">
        <div class="container">
            <div class="row">                
                <div class="col-md-12">
                    <div class="footer-col hi-icon-wrap hi-icon-effect-4 hi-icon-effect-4b">
                        <a href="https://www.facebook.com/raisoniworld" target="_blank" title="facebook" class="hi-icon">
                             <i class="fa fa-facebook" aria-hidden="true"></i>
                        </a>
                        <a href="https://twitter.com/raisoniworld" target="_blank" title="twitter" class="hi-icon">
                             <i class="fa fa-twitter" aria-hidden="true"></i>
                        </a>
                        <a href="https://www.youtube.com/user/rgingp/videos" target="_blank" title="youtube" class="hi-icon">
                             <i class="fa fa-youtube" aria-hidden="true"></i>
                        </a>
                        <a href="https://www.linkedin.com/in/raisonigroupofinstitutions/" target="_blank" title="linkedin" class="hi-icon">
                            <i class="fa fa-linkedin" aria-hidden="true"></i>
                        </a>
                        <a href="https://www.pinterest.com/raisoninagpur/" target="_blank" title="pinterest" class="hi-icon">
                             <i class="fa fa-pinterest-p" aria-hidden="true"></i>
                        </a>
                    </div> 
                </div>
            </div>
        </div>
    </footer>

    <section class="footer-copy-right text-white">
        <div class="container">
            <div class="row">
                <div class="col-md-12 text-center">
                    <div class="">
					
						<p><small>© 2019 Designed by <br> 

							<a href="https://globaledu.net.in/" target="_blank"> <small>Global Education Limited.</small></a>

						</small> <br>

							All Rights Reserved by G H Raisoni Institute Of Information Technology, Nagpur</p>
					</div>
                </div>
            </div>
        </div>
    </section>
    <!-- Footer Style Background ten End -->


    <!-- jQuery -->
    <script src="js/jquery.min.js"></script>

    <!-- Bootstrap Min js -->
    <script src="js/bootstrap.min.js"></script>
    <!-- jquery easing JS -->
    <script src="js/jquery.easing.min.js"></script>
    <!-- scrolling-nav JS -->
    <script src="js/scrolling-nav.js"></script>
    <!-- counterup -->
    <script src="js/jquery.counterup.min.js"></script>
    <!-- waypoints -->
    <script src="js/jquery.waypoints.min.js"></script>
    <!-- carousel -->
    <script src="js/owl.carousel.min.js"></script>
    <!-- wow js -->
    <script src="js/wow.min.js"></script>
    <!-- countdown JS -->
    <script src="js/countdown.js"></script>
    <!-- jquery.plate JS -->
    <script src="js/jquery.plate.js"></script>
    <!-- jarallax JS -->
    <script src="js/jarallax.min.js"></script>
    <!-- jquery scrollUp  JS -->
    <script src="js/jquery.scrollUp.min.js"></script>


    <!-- Map API Key -->
    <script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBWJqEQulUkszx4CH5sRCtFBXyMo8KWyd4&amp;callback=initMap"
            type="text/javascript"></script>
    <script src="js/map.js"></script>

    <!-- Main Custom JS -->
    <script src="js/custom.js"></script>
	

</body>
</html>