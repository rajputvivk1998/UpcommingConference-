<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Innovation and technology go hand in hand. When businesses and the way they operate shift from their traditional mode of operation and management ">
    <meta name="author" content="">

    <!-- Favicon -->
    <link rel="icon" type="image/png" href="images/favicon.png">
    <link rel="shortcut icon" type="image/png" href="images/favicon.png">

    <title>National Conference on “Recent Trends in Computer Science and Information Technology (NCRTCSIT-2019)”</title>

    <!-- Bootstrap Core CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">

    <!-- Custom CSS -->
    <link rel="stylesheet" type="text/css" href="css/style.css">

    <!-- Responsive stylesheet  -->
    <link rel="stylesheet" type="text/css" href="css/responsive.css">
  
</head>

<body id="page-top" data-spy="scroll" data-target=".navbar-fixed-top">

    <!-- Preloader -->
    <div id="preloader">
        <div id="status"></div>
    </div>
	
	

    <header class="main-header">	
		<section>
			<div class="container">
		  <div class="row " style="padding: 10px;">
			<div class="col-md-2">
			  <img src="images/logo/logo.png" class="img-fluid raisoni-logo">
			</div>
			<div class="col-md-8 ">         
			  <h3 class="font-weight-bold text-center">National Conference on <br>
				“Computational Intelligence and Deep Learning” 
				(NCCIDL)   
			  </h3>
			</div>
			<div class="col-md-2">
			  <img src="images/logo/RGI_LOGO.png" class="img-fluid raisoni-logo">
			</div>
		  </div>
		</div>
		</section>
        <!-- Navigation Start -->
        <div class="main-nav nav-transparent">
            <nav class="navbar navbar-default navbar-fixed-top" id="navbar-main">
                <div class="container">
                    <div class="navbar-header page-scroll">
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                        <!--<a class="navbar-brand page-scroll logo-black" href="#page-top"><img class="main-logo" src="images/logo/logo.png" alt=""> </a>
                        <a class="navbar-brand page-scroll logo-white" href="#page-top"><img class="main-logo" src="images/logo/logo.png" alt=""> </a>-->
                    </div>

                    <!-- Collect the nav links, forms, and other content for toggling -->
                    <div class="collapse navbar-collapse navbar-ex1-collapse">
                        <ul class="nav navbar-nav navbar-right">
                            <!-- Hidden li included to remove active class from about link when scrolled up past about section -->
                            <li> <a class="page-scroll" href="index.php">Home</a> </li>
                          
                            
							<li class="dropdown">
							  <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
							  About  <span class="caret"></span></a>
								<ul class="dropdown-menu submenu " role="menu">
									<li><a href="index.php#about">About Conference</a></li>									
									<li><a href="index.php#about">About GHRIIT</a></li>									
									<li><a href="index.php#about">About IJSRCSEIT Journal</a></li>									
									<li><a href="venu.php#aboutnagpur">About Nagpur</a></li>									
									<li><a href="KeynoteSpeaker.php">Keynote Speaker</a></li>									
								</ul>
							</li>							
							 
                            
							
							<li class="dropdown">
							  <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
							  Papers  <span class="caret"></span></a>
								<ul class="dropdown-menu submenu " role="menu">
									<li><a href="index.php#speakers">Call for Papers</a></li>									
									<li><a href="index.php#submission">Paper Submission</a></li>									
									<li><a href="index.php#PaperAccepted">Paper Accepted</a></li>									
								</ul>
							</li>
							
							<li class="dropdown">
							  <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
							  Registration  <span class="caret"></span></a>
								<ul class="dropdown-menu submenu " role="menu">
									<li><a href="index.php#Registration">Registration</a> </li>									
									<li><a href="index.php#ImportantDates">Important Dates</a> </li>									
									<li><a href="venu.php"> Venue</a></li>							
									<li><a href="index.php#download">Program and Schedule</a></li>							
								</ul>
							</li>
							
							
							
							
							
							
							
							<li class="dropdown">
							  <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
							Committee  <span class="caret"></span></a>
								<ul class="dropdown-menu submenu " role="menu">
									<li><a href="index.php#Conference">Conference Committee</a></li>
									<li><a href="index.php#Organizing">Organizing  Committee</a></li>
									<li><a href="#">Nagpur Travel and Tourism</a></li>
									<li><a href="#">Accommodation</a></li>
																	
								</ul>
							</li>
                            
                           
                           
							
							
                            <li> <a class="page-scroll" href="index.php#news">News</a></li>
                           
							<li class="dropdown">
							  <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
							Download  <span class="caret"></span></a>
								<ul class="dropdown-menu submenu " role="menu">
									<li><a href="#download">E-Brochure</a></li>
									
																	
								</ul>
							</li>
							
                           
							
							<li class="dropdown">
							  <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
							Contact  <span class="caret"></span></a>
								<ul class="dropdown-menu submenu " role="menu">
									<li><a href="#contact">Contact</a></li>
									<li><a href="contactperson.php">Contact Person</a></li>
									
																	
								</ul>
							</li>
							
							
							
							<!--<a class="navbar-brand" href="#page-top">
								<img class="main-logo" src="images/logo/RGI_LOGO.png" alt="">	
							</a>-->
                        </ul>
						
                    </div>
                    <!-- /.navbar-collapse -->
                </div>
                <!-- /.container -->
            </nav>
        </div>
    </header>

	<!-- Paper Submission Start -->
    <section class="ticket-area parallax" id="guidelines" >       
    </section>


	
	<!-- About Start -->
    <section class="about-area" id="aboutnagpur">
        <img class="left-img" src="images/left-img.png" alt="">
        <img class="right-img" src="images/right-img.png" alt="">
        <div class="container">
			<div class="col-md-12">
				<div class="about-col text-center">
					<h3>Keynote   <span>Speaker</span></h3>
				</div>
			</div>
		
			<div class="row">
               
                <div class="col-md-2">
                    <div class="venue-col">
                        <img src="images/Karbhari.jpg" alt="">
                    </div>
                </div>
				
				<div class="col-md-10">
                    <div class="venue-col text-justify">
                        <p>
							<b>Name :</b> Dr. Karbhari Vishwanath Kale 						
                        </p> 
						<p>
							<b>Designation :</b> Professor & Director B.C.U.D.
								<br>
								Dept. of Computer Science and Information Technology,<br>
								Dr. Babasaheb Ambedkar Marathwada, University,<br>
								(NAAC Accredited by ‘A’ Grade)<br>
								Aurangabad - 431004 (MS) India.

                        </p> 
						
						 <p>
							<b>Educational Details :</b> Ph. D. (Physics), MCA (Faculty of Engineering & Technology). M.Sc. (Physics), B.Ed, B.Sc.						
                        </p> 
						
						<p>
							<b>Date of Birth :</b> 02.08.1962
                        </p> 
						
						<p>
							<b>Field of Interest :</b> Image Processing, Pattern Recognition, Computer Vision, Software Engineering, Artificial Intelligence, Neural Network, Robotics, Decision Support System and Intelligence system, Biometrics, Bio-informatics, Remote Sensing and GIS, Sensor Networks and Sensor Web Enablement (SWE), and Embedded Systems etc.
                        </p> 
                    </div>
                </div>
               
            </div>
		
            <div class="row">
			
				<div class="col-md-6">
				
					
				<div class="col-md-12">
				    <div class="speaker-info submission">
						<h3>Administrative Experience </h3>
						<ul>
							<li>Professor & Head, Department of Comp. Sci. & IT</li>
							<li>5 Times Programme Coordinator Refresher & Orientation Course, UGC</li>
							<li>Academic Staff College, Dr. B. A. M University Aurangabad</li>
							<li>Programme Coordinator, UGC-SAP(II) DRS Phase-I & Phase-II</li>
							<li>Director, UNIC, Dr. B. A. M University Aurangabad</li>
							<li>I/C Registrar, Dr. B. A. M University Aurangabad (24 January 2015- 21 February 2015)</li>
							<li>Vice Chancellor, Dr. B. A. M. University Aurangabad, 08 to 14 September 2015</li>							
						</ul>
					</div>
				</div>
				
				<div class="col-md-12">
				    <div class="speaker-info submission">
						<h3>Present Position </h3>
						<ul>
							<li>Director, Board of College and University Development, Dr. Babasaheb</li>
							<li>Ambedkar Marathwada University, Aurangabad</li>
							<li>President, ICT Section, The Indian Science Congress Association, Kolkata (2015-2019)</li>
														
						</ul>
					</div>
				</div>
				
				<div class="col-md-12">
				    <div class="speaker-info submission">
						<h3> Statutory Authorities Member of Board of Studies</h3>
						<ul>
							<li>Dr. Babasaheb Ambedkar Marathwada University, Aurangabad (Computer Science & IT)</li>
							<li>SRT University, Nanded (Computer Science)</li>
							<li>Amravati University, Amravati (Computer Science)</li>
							<li>YCM Open University, Nashik (Computer Science)`</li>
							<li>Gulbarga University, Gulbarga (Computer Science)</li>					
							<li>Veer Narmad South Gujarat University, Surat (Information Technology)</li>					
						</ul>
					</div>
				</div>
			
				</div>
				
				<div class="col-md-6">
					<div class="col-md-12">
				    <div class="speaker-info submission">
						<h3> Member of Faculty of Science</h3>
						<ul>
							<li>Dr. Babasaheb Ambedkar Marathwada University, Aurangabad</li>
							<li>Amravati University, Amravati</li>
											
						</ul>
					</div>
				</div>
				
				<div class="col-md-12">
				    <div class="speaker-info submission">
						<h3> Award/ Fellowship </h3>
						<ul>
							<li>VIJAY SHREE</li>
							<li>Plaque by Who’s who in the World in Computer Science</li>
							<li>Amazing Idea Award, IEEE  Science and Information (SAI) Conference 2013 London, UK, October 2013</li>
							<li>Excellent Paper Award, IACSIT International Conference on Computer and Electrical Engineering (ICCEE-2013), Paris, France, October 2013</li>
							<li>UGC One Time Research Grant, 2013-14 & 2014-15</li>					
						</ul>
					</div>
				</div>
				
				
				<div class="col-md-12">
				    <div class="speaker-info submission">
						<h3> Research Guide</h3>
						
						<ul>
							<li>Computer Science, Information Technology, Computer Science & Engineering, Dr. Babasaheb Ambedkar Marathwada University Aurangabad & Other Universities in India</li>
									
						</ul>
					</div>
				</div>
				</div>
			</div>
			
			<hr>
			
            <div class="row">
               
                <div class="col-md-2">
                    <div class="venue-col">
                        <img src="images/Vilas.jpg" alt="">
                    </div>
                </div>
				
				<div class="col-md-10">
                    <div class="venue-col text-justify">
                        <p>
							<b>Name :</b> Dr. Vilas M. Thakare
						
                        </p> 
						<p>
							<b>Designation :</b> Professor and Head in Computer Science
								<br>
								Faculty of Engineering & Technology,<br>
								Post Graduate Department of Computer Science, <br>
								SGB Amravati University, Amravati.

                        </p> 
						
						 <p>
							<b>Educational Details :</b> Ph.D.(Computer Science), M.E. (Advance Electronics), M.Sc.(Applied Electronics), Diploma in Computer Management					
                        </p> 
						
						<p>
							<b>Date of Birth :</b> 09.09.1962
                        </p> 
						
						<p>
							<b>Field of Interest :</b> Computer Architectures, AI, Robotics, etc.
                        </p> 
                    </div>
                </div>
               
            </div>
		
            <div class="row">
			
				<div class="col-md-6">
				
					
				<div class="col-md-12">
				    <div class="speaker-info submission">
						<h3>Professional Recognition</h3>
						<ul>
							<li>Software Development & Computerization of Finance, Library, Exam</li>
							<li>Admission Process, Revaluation Process of Amravati University</li>
							<li>Member, Academic Council, TUPLES InfoTech, Lucknow</li>
										
						</ul>
					</div>
				</div>
				
				<div class="col-md-12">
				    <div class="speaker-info submission">
						<h3>Member of Learned Societies </h3>
						<ul>
							<li>Institute of Engineers (Life Member)</li>
							<li>Indian Society of Technical Education ISTE (Life Member)</li>
							<li>Computer Society of India CSI (Member)</li>
							
														
						</ul>
					</div>
				</div>
				
				<div class="col-md-12">
				    <div class="speaker-info submission">
						<h3> Worked on various bodies of universities</h3>
						<ul>
							<li>Member of Academic Council</li>
							<li>Member, faculty of Engineering & Science</li>
							<li>Chairman, BOS (Comp. Sci.)</li>
							<li>Member, IT Committee</li>
							<li>Member, Networking Committee</li>
							<li>Member NAAC, BUTR, ASU, DRC, RRC, SEC, CAS, NSD.</li>
							<li>Member, Admission Committee (MCA/PGDCS)</li>
							<li>Member, Expert Committee for Library Computerization</li>
										
						</ul>
					</div>
				</div>
				
				<div class="col-md-12">
				    <div class="speaker-info submission">
						<h3>Award/ Fellowship </h3>
						<ul>
							<li>National Level excellent paper award at National Conference, Gwalior</li>
							<li>UGC fellowship(10th Plan)</li>
							<li>Amravati University, Amravati</li>
											
						</ul>
					</div>
				</div>
			
				</div>
				
				<div class="col-md-6">
				
				
				<div class="col-md-12">
				    <div class="speaker-info submission">
						<h3>Research Experience</h3>
						<ul>
							<b>Ph.D.</b>
							<li>Topic "Study of Computer Architectures & Related AI Techniques for trajectories of Robot." at Dr. B. A. M. U., Aurangabad </li>
										
						</ul>
					</div>
				</div>
				
				
				<div class="col-md-12">
				    <div class="speaker-info submission">
						<h3>      Research Project completed</h3>
						
						<ul>
							<li>Minor research project Title "Study & Development of ES for control of 4 legged robot device model.", </li>
									
						</ul>
					</div>
				</div>
				
				<div class="col-md-12">
				    <div class="speaker-info submission">
						<h3>   UGC Ph.D. Guide / Supervisor</h3>
						
						<ul>
							<li>10 research scholars have been applied for Ph.D. registration</li>
									
						</ul>
					</div>
				</div>
				
				<div class="col-md-12">
				    <div class="speaker-info submission">
						<h3>      M.E./ M.S. /M.Phil./ M.C.A. Guide</h3>
						
						<ul>
							<li>Guided more than 300 projects</li>
									
						</ul>
					</div>
				</div>
				
				<div class="col-md-12">
				    <div class="speaker-info submission">
						<h3>      Research Paper published & Presented (Total 85)</h3>
						
						<ul>
							<li>Journal papers 19</li>
							<li>International Conferences 16</li>
							<li>National Conferences 60</li>
									
						</ul>
					</div>
				</div>
				
				<div class="col-md-12">
				    <div class="speaker-info submission">
						<h3>       Invited talks</h3>
						
						<ul>
							<li>More than 55 Keynote addresses and Invited talks delivered in India and abroad</li>
							
						</ul>
					</div>
				</div>
				
				
				</div>
			</div>
        </div>
    </section>

<!-- Footer Start -->
    <footer class="footer-area">
        <div class="container">
            <div class="row">                
                <div class="col-md-12">
                    <div class="footer-col hi-icon-wrap hi-icon-effect-4 hi-icon-effect-4b">
                        <a href="https://www.facebook.com/raisoniworld" target="_blank" title="facebook" class="hi-icon">
                             <i class="fa fa-facebook" aria-hidden="true"></i>
                        </a>
                        <a href="https://twitter.com/raisoniworld" target="_blank" title="twitter" class="hi-icon">
                             <i class="fa fa-twitter" aria-hidden="true"></i>
                        </a>
                        <a href="https://www.youtube.com/user/rgingp/videos" target="_blank" title="youtube" class="hi-icon">
                             <i class="fa fa-youtube" aria-hidden="true"></i>
                        </a>
                        <a href="https://www.linkedin.com/in/raisonigroupofinstitutions/" target="_blank" title="linkedin" class="hi-icon">
                            <i class="fa fa-linkedin" aria-hidden="true"></i>
                        </a>
                        <a href="https://www.pinterest.com/raisoninagpur/" target="_blank" title="pinterest" class="hi-icon">
                             <i class="fa fa-pinterest-p" aria-hidden="true"></i>
                        </a>
                    </div> 
                </div>
            </div>
        </div>
    </footer>

    <section class="footer-copy-right text-white">
        <div class="container">
            <div class="row">
                <div class="col-md-12 text-center">
                    <div class="">
					
						<p><small>© 2019 Designed by <br> 

							<a href="https://globaledu.net.in/" target="_blank"> <small>Global Education Limited.</small></a>

						</small> <br>

							All Rights Reserved by G H Raisoni Institute Of Information Technology, Nagpur</p>
					</div>
                </div>
            </div>
        </div>
    </section>
    <!-- Footer Style Background ten End -->


    <!-- jQuery -->
    <script src="js/jquery.min.js"></script>

    <!-- Bootstrap Min js -->
    <script src="js/bootstrap.min.js"></script>
    <!-- jquery easing JS -->
    <script src="js/jquery.easing.min.js"></script>
    <!-- scrolling-nav JS -->
    <script src="js/scrolling-nav.js"></script>
    <!-- counterup -->
    <script src="js/jquery.counterup.min.js"></script>
    <!-- waypoints -->
    <script src="js/jquery.waypoints.min.js"></script>
    <!-- carousel -->
    <script src="js/owl.carousel.min.js"></script>
    <!-- wow js -->
    <script src="js/wow.min.js"></script>
    <!-- countdown JS -->
    <script src="js/countdown.js"></script>
    <!-- jquery.plate JS -->
    <script src="js/jquery.plate.js"></script>
    <!-- jarallax JS -->
    <script src="js/jarallax.min.js"></script>
    <!-- jquery scrollUp  JS -->
    <script src="js/jquery.scrollUp.min.js"></script>


    <!-- Map API Key -->
    <script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBWJqEQulUkszx4CH5sRCtFBXyMo8KWyd4&amp;callback=initMap"
            type="text/javascript"></script>
    <script src="js/map.js"></script>

    <!-- Main Custom JS -->
    <script src="js/custom.js"></script>
	

</body>
</html>